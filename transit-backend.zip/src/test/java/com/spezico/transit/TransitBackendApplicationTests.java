package com.spezico.transit;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TransitBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
