package com.spezico.transit;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TransitBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(TransitBackendApplication.class, args);
	}

}
